/*import MOBPHON_20230603.MobilePhone;

import MOBPHON_20230603.Tablet;

public class Main {
    public static void main(String[] args) {

        MobilePhone myPhon = new MobilePhone();
        myPhon.hasSensor =true;
        myPhon.model = "iPhone 3G";
        myPhon.hasBlueTooth = true;
        myPhon.msize = 6.7;
        System.out.println(myPhon.model);
        myPhon.addCredits(10,"SHha273GD");
        myPhon.call("mama");

        MobilePhone nokia = new MobilePhone();
        nokia.model = "Nokia X500";
        nokia.msize = 40;
        nokia.hasSensor = false;
        nokia.wiFi = false;
        System.out.println(nokia.model);
        //nokia.credits = 10;
        nokia.call("other");
    }
}*/
