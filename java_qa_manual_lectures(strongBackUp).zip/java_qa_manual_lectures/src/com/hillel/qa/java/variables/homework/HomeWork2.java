package com.hillel.qa.java.variables.homework;

public class HomeWork2 {
    /**
     * <h2>Вимоги:</h2>
     * <ul style="font-size:12px">
     *     <li>Розкоментуйте код</li>
     *     <li>Виправіть помилки щоб код можна було вивести в консоль</li>
     * </ul>
     */
    public static void main(String[] args) {
        String country = "Ukraine";
        String city = "Odessa";
        int age = 227;
        double square = 162.4;
        System.out.println(country);
        System.out.println(city);
        System.out.println(age);
        System.out.println(square);

    }
}
