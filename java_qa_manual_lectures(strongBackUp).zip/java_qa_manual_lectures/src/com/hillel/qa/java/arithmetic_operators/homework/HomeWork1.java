package com.hillel.qa.java.arithmetic_operators.homework;

public class HomeWork1 {
    /**
     * <p style="font-size:12px">
     * Написати програму, яка виводить на екран рік народження мого друга.
     * </p>
     *<br>
     * <h2>Вимоги:</h2>
     * <ul style="font-size:12px">
     *     <li>Створіть змінну currentYear, яка буде містити поточний рік.</li>
     *     <li>Створіть змінну friendYear, яка буде містити рік народження друга.</li>
     *     <li>Вивести в консоль "Моєму другу (число) років".</li>
     * </ul>
     */

    public static void main(String[] args) {
        short friendYear = 2023;
        short currentYear = 2023;
        if (currentYear >= friendYear) {

            short friendAge = (short) (currentYear - friendYear);
            System.out.print("Моєму другу ");
            System.out.print(friendAge);
            System.out.print(" років");
        }
        else {
            System.out.print("Двій друг ще не народився");
        }
    }
}
