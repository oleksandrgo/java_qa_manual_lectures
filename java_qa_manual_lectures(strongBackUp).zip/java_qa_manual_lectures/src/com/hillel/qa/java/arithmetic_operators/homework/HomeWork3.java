package com.hillel.qa.java.arithmetic_operators.homework;

import java.util.Locale;

public class HomeWork3 {
    /**
     * <p style="font-size:12px">
     * У змінну digits потрібно записати рядок "80".
     * Обовʼязково використовуй змінні a, b, c.
     * </p>
     * <br>
     * <h2>Вимоги:</h2>
     * <ul style="font-size:12px">
     *     <li>Не змінюй значення змінних a, b, c.</li>
     *     <li>Для ініціалізації змінної digits використовуй a, b, c.</li>
     *     <li>Програма повинна виводити на екран значення змінної digits.</li>
     * </ul>
     *
     */
    public static void main(String[] args) {
        int a = 4;
        int b = 4;
        int c = 0;
        String ab = String.valueOf(a + b);
        String digits = ab + c;

        System.out.println(digits);
    }
}
