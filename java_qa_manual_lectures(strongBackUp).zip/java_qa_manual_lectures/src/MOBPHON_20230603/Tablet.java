/*package MobilePhone;
import MOBPHON_20230603.MobilePhone;

public class Tablet {

    public class Tablet extends MobilePhone{

    }
}
*/